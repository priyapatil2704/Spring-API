package com.adapty.ecommerce.services;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adapty.ecommerce.entities.Cart;
import com.adapty.ecommerce.entities.Product;
import com.adapty.ecommerce.entities.STATUS;
import com.adapty.ecommerce.repository.CartRepository;
import com.adapty.ecommerce.repository.ProductRepository;

@Service
public class CartImpl implements CartInterface{
    @Autowired
    ProductRepository prObj;
    @Autowired
    CartRepository repoObj;
    public List<Cart> fetchAllProducts(){
    
       return repoObj.findAll();
    }

    public Optional<Cart> fetchByCartItemId(String cartItemId){
        return repoObj.findById(cartItemId);
    }

    public String addToCart(Cart cartObj){
        Optional<Product> d1 =prObj.findById(cartObj.getProductId());
        if(d1.isPresent()){
        if(d1.get().getProductStatus() ==STATUS.ACTIVE){
            //d1.get().setProductStatus(STATUS.INACTIVE);
            repoObj.save(cartObj);
           return "Object added";
        }
        else{
            return "Object does not exists";
        }
    }
    else{
        return "product not found";
    }
            // repoObj.save(cartObj);
            // return "Added";
        
      
    }

    //delete product by item id
    public String deleteItemByCartId(String cartItemId){
        repoObj.deleteById(cartItemId);
        return "Deleted item successfully";
    }

    //delete by product id

    public String deleteItemByProductId(String productId){
       
        repoObj.deleteByProductId(productId);
        return "Deleted";
    }

    //update product

    public String updateByCartItemId(Cart cartObj){
        if(cartObj.getCartItemId()==null){
            return null;
        }
        else{
            Optional<Cart> c1=repoObj.findById(cartObj.getCartItemId());
            c1.get().setCartItemQty(cartObj.getCartItemQty());
            c1.get().setProductId(cartObj.getProductId());
            repoObj.deleteById(cartObj.getCartItemId());
            return "Updated successfully";


        }
    }

    // find total price of products
   // public float findTotalPrice()
}
