package com.adapty.ecommerce.entities;

public enum STATUS {
    ACTIVE,
    INACTIVE
}
