package com.adapty.ecommerce.repository;


import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adapty.ecommerce.entities.Cart;

public interface CartRepository extends JpaRepository<Cart,String>{
    @Transactional
    //@Query(value = "delete from cart where product_id=E101 and cart_item_id=190",nativeQuery=true) 
    public Optional<String> deleteByProductId(String productId);
}
