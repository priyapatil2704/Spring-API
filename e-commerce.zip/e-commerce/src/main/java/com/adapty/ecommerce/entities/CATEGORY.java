package com.adapty.ecommerce.entities;

public enum CATEGORY {
    ELECTRONICS,
    MOBILES,
    FASHION,
    HOME,
    APPLIANCES,
    GROCERY,
    BEAUTY
}
